﻿namespace NaviriaAPI.Entities.EmbeddedEntities
{
    public class Tags
    {
        public string TagName { get; set; } = String.Empty;
    }
}
