﻿namespace NaviriaAPI.DTOs.FeaturesDTOs
{
    public class SharedInterestsDto
    {
        public List<string> SharedCategoryNames { get; set; } = new();
        public List<string> SharedTagNames { get; set; } = new();
    }

}
