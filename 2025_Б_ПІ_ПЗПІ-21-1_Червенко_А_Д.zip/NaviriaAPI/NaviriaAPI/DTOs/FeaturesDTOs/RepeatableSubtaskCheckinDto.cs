﻿namespace NaviriaAPI.DTOs.FeaturesDTOs
{
    public class RepeatableSubtaskCheckinDto
    {
        public DateTime Date { get; set; }
    }

}
