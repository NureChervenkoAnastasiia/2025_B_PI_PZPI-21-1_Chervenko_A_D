﻿namespace NaviriaAPI.DTOs.Quote
{
    public class QuoteCreateDto
    {
        public string Text { get; set; } = string.Empty;
        public string Language { get; set; } = string.Empty;
    }
}
