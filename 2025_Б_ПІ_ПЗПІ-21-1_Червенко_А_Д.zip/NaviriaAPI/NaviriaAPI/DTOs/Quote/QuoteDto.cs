﻿namespace NaviriaAPI.DTOs.Quote
{
    public class QuoteDto
    {
        public string Id { get; set; } = string.Empty;
        public string Text { get; set; } = string.Empty;
        public string Language { get; set; } = string.Empty;
    }
}


