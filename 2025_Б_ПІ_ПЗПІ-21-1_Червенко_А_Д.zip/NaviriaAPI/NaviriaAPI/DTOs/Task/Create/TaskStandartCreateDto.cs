﻿namespace NaviriaAPI.DTOs.Task.Create
{
    public class TaskStandardCreateDto : TaskCreateDto
    {
        public TaskStandardCreateDto()
        {
            Type = "standard";
        }
    }
}
