﻿using NaviriaAPI.DTOs.Task.View;

namespace NaviriaAPI.DTOs.TaskDtos
{
    public class TaskStandardDto : TaskDto
    {
        public TaskStandardDto()
        {
            Type = "standard";
        }
    }
}
