﻿namespace NaviriaAPI.DTOs.Task.Update
{
    public class TaskStandardUpdateDto : TaskUpdateDto
    {
        public TaskStandardUpdateDto()
        {
            Type = "standard";
        }
    }
}
