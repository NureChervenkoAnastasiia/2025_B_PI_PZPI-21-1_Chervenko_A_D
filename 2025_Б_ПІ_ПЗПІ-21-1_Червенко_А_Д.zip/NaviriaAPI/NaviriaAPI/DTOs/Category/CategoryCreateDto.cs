﻿namespace NaviriaAPI.DTOs.Category
{
    public class CategoryCreateDto
    {
        public string Name { get; set; } = string.Empty;
    }

}
