﻿namespace NaviriaAPI.DTOs.Category
{
    public class CategoryUpdateDto
    {
        public string Name { get; set; } = string.Empty;
    }

}
