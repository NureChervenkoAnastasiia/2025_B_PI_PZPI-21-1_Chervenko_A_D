﻿namespace NaviriaAPI.DTOs.Folder
{
    public class FolderUpdateDto
    {
        public string Name { get; set; } = string.Empty;
    }
}
