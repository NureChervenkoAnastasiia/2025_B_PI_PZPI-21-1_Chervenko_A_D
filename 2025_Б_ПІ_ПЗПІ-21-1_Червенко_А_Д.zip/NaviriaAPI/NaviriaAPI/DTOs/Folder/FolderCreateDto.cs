﻿namespace NaviriaAPI.DTOs.Folder
{
    public class FolderCreateDto
    {
        public string UserId { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
    }
}
