﻿namespace NaviriaAPI.Helpers
{
    public enum AchievementTrigger
    {
        OnRegistration,
        OnPhotoUploading,
        OnLongTaskCompleted,
        On5TaskInWeekTaskCompleted,
        OnFirstTaskCompleted,
        OnAdding5Friends,
    }
}
