namespace NaviriaAPI.Helpers;

public static class Roles
{
    public const string ProUser = "ProUser";
    public const string User = "User";
}