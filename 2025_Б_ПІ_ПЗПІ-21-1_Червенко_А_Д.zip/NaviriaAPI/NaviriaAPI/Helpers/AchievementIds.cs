﻿namespace NaviriaAPI.Helpers
{
    public class AchievementIds
    {
        public const string Registration = "680cbdd3aa61ece2f91f0d78";
        public const string FiveTasksInWeekCompleted = "680cbdd4aa61ece2f91f0d81";
        public const string FirstTaskCompleted = "680cbde90319e1e5d9288643";
        public const string PhotoUploaded = "681bcccf48a8f66a72ad7615";
        public const string LongTaskCompleted = "681bcccf48a8f66a72ad7616";
        public const string FiveFriendAdded = "681bcccf48a8f66a72ad7618";
    }
}
