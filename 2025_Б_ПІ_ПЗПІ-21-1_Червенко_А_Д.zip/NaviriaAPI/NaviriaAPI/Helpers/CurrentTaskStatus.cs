﻿namespace NaviriaAPI.Helpers
{
    public enum CurrentTaskStatus
    {
        InProgress,
        DeadlineMissed,
        Completed,
        CompletedInTime,
        CompletedNotInTime
        
    }
}
