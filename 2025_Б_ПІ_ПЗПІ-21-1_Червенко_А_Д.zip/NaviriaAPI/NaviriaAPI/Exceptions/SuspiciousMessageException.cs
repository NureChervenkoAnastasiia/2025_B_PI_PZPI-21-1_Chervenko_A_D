﻿namespace NaviriaAPI.Exceptions
{
    public class SuspiciousMessageException : Exception
    {
        public SuspiciousMessageException(string message) : base(message) { }
    }
}
